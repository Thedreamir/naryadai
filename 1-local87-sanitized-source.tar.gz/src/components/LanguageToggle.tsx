import {useLocale} from '../lib/locale'
export default function LanguageToggle(){const {locale,setLocale}=useLocale();return <select aria-label={locale==='kz'?'Тіл':'Язык'} value={locale} onChange={e=>setLocale(e.target.value==='kz'?'kz':'ru')} className="language-toggle"><option value="ru">Русский</option><option value="kz">Қазақша</option></select>}
