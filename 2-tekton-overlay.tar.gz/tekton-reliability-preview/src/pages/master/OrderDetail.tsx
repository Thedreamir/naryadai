import PhotoCompare from '../../components/PhotoCompare'
import {reviewDisplay,reviewArchiveDisplay,reviewPresentation} from '../../lib/ai-review-display.mjs'
import {useEffect, useState} from 'react'
import {useParams, useNavigate} from 'react-router-dom'
import * as H from '../../lib/data'
import {Card} from '../../components/ui/card'
import {Button} from '../../components/ui/button'
import {Badge} from '../../components/ui/badge'
import type {Actor} from '../../App'
import {statusOf, eventLabel} from '../../lib/status'
export default function MasterOrderDetail({actor}:{actor:Actor}){
  const {id}=useParams(); const nav=useNavigate()
  const [st,setSt]=useState<any>(null); const [err,setErr]=useState(''); const [busy,setBusy]=useState(false)
  const [assignee,setAssignee]=useState(''); const [priority,setPriority]=useState('normal'); const [manageReason,setManageReason]=useState('')
  const [archiveReceipt,setArchiveReceipt]=useState<any>(null)
  const [score,setScore]=useState(4); const [compare,setCompare]=useState(false)
  const load=()=>H.state().then(setSt).catch(e=>setErr(e.message))
  useEffect(()=>{load()},[id])
  if(err&&!st) return <Card className="text-danger">{err}</Card>
  if(!st) return <div className="text-muted py-10">Загрузка…</div>
  const o=st.orders.find((x:any)=>x.id===Number(id))
  if(!o) return <Card>Наряд не найден.</Card>
  const go=async(status:string,reason?:string,extra?:any)=>{setBusy(true);setErr('')
    try{const response=await H.transition(o.id,{status,version:o.version,reason,...extra});if(status==='ai_review')setArchiveReceipt(response);await load()}catch(e){setErr((e as Error).message)}finally{setBusy(false)}}
  const manage=async(action:'reassign'|'priority'|'cancel')=>{if(action==='cancel'&&!confirm('Отменить наряд? Дальнейшие действия будут заблокированы. Это не подтверждает остановку физических работ.'))return;setBusy(true);setErr('');try{await H.manageOrder(o.id,action,{assignee,priority,reason:manageReason});if(action==='cancel')nav('/');else await load()}catch(e){setErr((e as Error).message)}finally{setBusy(false)}}
  const receipt=archiveReceipt?.version===o.version?archiveReceipt:H.reviewArchiveReceipt(actor.id,o.id,o.version)
  const presentation=reviewPresentation(o.ai_result,receipt)
  const before:string[]=[...(o.before_photos||[]),...(o.intake_photos||[]).filter((p:any)=>p.phase==='before_intake'&&p.url).map((p:any)=>p.url)]; const after:string[]=(o.closure?.photos)||[]
  return <div className="space-y-4 max-w-3xl">{err&&<Card role="alert" className="text-danger">{err}</Card>}
    <button className="text-muted text-[14px]" onClick={()=>nav(-1)}>← Назад</button>
    <div><div className="text-[12px] text-muted">НАРЯД #{o.id} · {o.section} · {o.assignee}</div>
      <h1 className="text-[24px] font-bold">{o.title}</h1>
      <div className="text-[14px] text-muted">{o.equipment} · срок {new Date(o.deadline).toLocaleString('ru',{timeZone:'Asia/Almaty',day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'})} · статус: {statusOf(o.status).label}</div></div>
    {!['closed','completed','ai_review'].includes(o.status)&&<Card className="space-y-3"><h2 className="font-semibold text-[15px]">Управление нарядом</h2><label className="block text-[13px]">Основание<input aria-label="Основание управления" className="mt-1 border border-border rounded-[10px] p-3 w-full" value={manageReason} onChange={e=>setManageReason(e.target.value)} placeholder="Причина изменения"/></label>
      {['issued','queued','rejected'].includes(o.status)?<div className="flex gap-2"><select aria-label="Новый исполнитель" className="border border-border rounded-[10px] p-3 flex-1 min-w-0" value={assignee} onChange={e=>setAssignee(e.target.value)}><option value="">Выберите исполнителя</option>{st.employees.filter((e:any)=>e.role==='worker'&&e.is_active&&e.id!==o.assignee_id).map((e:any)=><option key={e.id} value={e.id}>{e.name}</option>)}</select><Button disabled={busy||!assignee||manageReason.trim().length<3} onClick={()=>manage('reassign')}>Переназначить</Button></div>:<p className="text-[12px] text-muted">Переназначение недоступно после принятия: активная работа не передаётся молча.</p>}
      <div className="flex gap-2"><select aria-label="Новый приоритет" value={priority} onChange={e=>setPriority(e.target.value)} className="border border-border rounded-[10px] p-3 flex-1">{[['normal','Обычный'],['high','Высокий'],['emergency','Аварийный'],['planned','Плановый']].map(([v,l])=><option key={v} value={v}>{l}</option>)}</select><Button disabled={busy||priority===o.priority||manageReason.trim().length<3} onClick={()=>manage('priority')}>Изменить приоритет</Button></div>
      <Button variant="outline" disabled={busy||manageReason.trim().length<3} onClick={()=>manage('cancel')}>Отменить наряд</Button><p className="text-[12px] text-muted">Изменения записываются в журнал. Отмена убирает наряд из очередей и блокирует переходы, но не означает физическую остановку работ.</p></Card>}
    {(before.length>0||after.length>0)&&<Card className="space-y-3">
      <div className="flex items-center justify-between"><div className="font-semibold text-[15px]">Фото до / после</div>
        {before.length>0&&after.length>0&&<Button variant="outline" onClick={()=>setCompare(c=>!c)}>{compare?'Обычный вид':'Сравнить до/после'}</Button>}</div>
      {compare&&before.length>0&&after.length>0?
        <PhotoCompare before={before[0]} after={after[0]}/>:
        <div className="flex gap-3 flex-wrap">{before.length===0&&after.length>0&&<div className="text-[13px] text-muted self-center">Фото до отсутствует — сравнение недоступно.</div>}{before.map((p,i)=><div key={'b'+i}><div className="text-[12px] text-muted mb-1">До</div><img src={p} className="h-36 rounded-[14px]" alt="Фото до"/></div>)}
        {after.map((p,i)=><div key={'a'+i}><div className="text-[12px] text-muted mb-1">После</div><img src={p} className="h-36 rounded-[14px]" alt="Фото после"/></div>)}</div>}
      {o.closure?.photo_evidence?.map((p:any)=><div key={p.sha256} className="text-[12px] text-muted">Фото получено сервером: {new Date(p.server_received_at).toLocaleString('ru')} · {Math.round(p.byte_size/1024)} КБ.{p.duplicate_order_id?` Совпадает с фото наряда #${p.duplicate_order_id}.`:''} Время съёмки не подтверждено.</div>)}
    </Card>}
    {o.closure?.works&&<Card><div className="font-semibold text-[15px] mb-1">Выполненные работы</div>
      <div className="text-[14px]">{o.closure.works}</div>
      {o.closure.fault_code&&<div className="text-[13px] text-muted mt-1">Шифр: {o.closure.fault_code}</div>}</Card>}
    {o.status==='completed'&&<Card className="space-y-3 border-primary/40">
      <div className="font-semibold text-[15px]">Проверка закрытия</div>
      <Button size="big" className="w-full" disabled={busy} onClick={()=>go('ai_review')}>Проверить отчёт</Button>
      <div className="text-[12px] text-muted">Проверка по правилам. При ошибке обновите наряд, автоматического повтора нет. Решение принимает мастер.</div>
    </Card>}
    {o.ai_result&&<Card className="space-y-2">
      <div className="flex items-center gap-2"><span className="font-semibold text-[15px]">Карточка оснований</span><Badge tone="gray">Проверка отчёта</Badge></div>
      <div role="status" className="text-[12px] text-muted">{reviewArchiveDisplay(archiveReceipt?.version===o.version?archiveReceipt:H.reviewArchiveReceipt(actor.id,o.id,o.version)).label}</div>
      <div className="font-semibold">{presentation.verdictLabel}</div>
      <div className="text-[14px]">Оценка проверки: {presentation.scoreLabel}</div>
      {o.ai_result.report_master&&<details><summary className="min-h-12 flex items-center text-[13px] cursor-pointer">Подробный отчёт мастеру</summary><p className="whitespace-pre-line text-[13px]">{o.ai_result.report_master}</p></details>}
      <div className="text-[12px] text-muted">{reviewDisplay(o.ai_result).detail}</div>
      <ul className="list-disc pl-5 text-[14px] space-y-0.5">{(o.ai_result.reasons||[]).map((r:string,i:number)=><li key={i}>{r}</li>)}</ul>
      <div className="text-[12px] text-muted">Физическое выполнение ремонта не подтверждено. Решение принимает мастер. Оценка не калибрована на данных предприятия.</div>
      {(o.ai_result.limitations||[]).map((x:string,i:number)=><div className="text-[12px] text-muted" key={i}>{x}</div>)}
    </Card>}
    {o.status==='ai_review'&&<Card className="space-y-3">
      <div className="font-semibold text-[15px]">Решение мастера</div>
      <div className="flex items-center gap-3"><span className="text-[14px]">Оценка:</span>
        <div className="flex gap-1">{[1,2,3,4,5].map(n=><button key={n} onClick={()=>setScore(n)} className={"h-12 w-12 rounded-[12px] font-bold "+(score===n?'bg-primary text-primary-ink':'bg-surface border border-border')}>{n}</button>)}</div></div>
      <Button size="big" className="w-full" disabled={busy} onClick={()=>go('closed',undefined,{human_score:score})}>Закрыть наряд</Button>
      <Button size="big" variant="outline" className="w-full" disabled={busy} onClick={()=>{const r=prompt('Причина возврата на доработку');if(r)go('rework',r)}}>Вернуть на доработку</Button>
    </Card>}
    <Card><div className="font-semibold text-[14px] mb-2">Журнал действий</div>
      {st.events.filter((e:any)=>e.order_id===o.id).map((e:any)=><div key={e.id} className="text-[12px] text-muted py-1 border-t border-border first:border-0">{e.actor} · {eventLabel(e.new_status)} · {new Date(e.created_at).toLocaleString('ru',{timeZone:'Asia/Almaty',day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'})}{e.reason?' · '+e.reason:''}</div>)}</Card>
  </div>
}
